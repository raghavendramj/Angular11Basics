import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events-example',
  templateUrl: './events-example.component.html',
  styleUrls: ['./events-example.component.css']
})
export class EventsExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  fname = "Enter your firstname";
  lname = "Enter your last name";
  isFormReady = false;

  submitForm(){
    alert("submitForm clicked!");
  }

}
