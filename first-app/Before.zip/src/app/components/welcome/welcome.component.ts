import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {


  public statement = " Welcome to angular!";
  public currDate = new Date();
  public isFormReady = true;
  public imageURLOne = "https://picsum.photos/id/237/200/300";
  public imageURLTwo = "https://picsum.photos/seed/picsum/200/300";
  public classes = "special";
  public width = "250px";
  public widthpx = "350";
  public styleExpression = `width: 300px,  height: 250px `;
  public stylesRecord:Record<string, string> = {width: '100px', height: '150px'};

  public isSpecial = 'special';


  constructor() { 
    setTimeout(() => {
      this.isFormReady = false;
    }, 2000);
  }
  ngOnInit(): void {
  }

  submitForm(){
    alert(" Thanks for submmiting the form!" + this.currDate);    
    this.imageURLOne = "https://picsum.photos/seed/picsum/200/300";
    this.classes = 'red';
    this.isSpecial = 'red';
  }

}
