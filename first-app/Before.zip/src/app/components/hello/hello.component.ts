import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
            <h2>{{title}}</h2>
            
            <span> {{nameOfTheApp}} </span>
            <span> The sum of 10 + 13 is {{getValue()}} </span>
            <ul>
              <li *ngFor="let fruit of fruits"> {{fruit}}
            </ul>
            `,
  styles: [`
          div {
              font-weight: bold; 
              font-size: 50px;
          }
    `]
})
export class HelloComponent implements OnInit {

  public title = "IT Solutions!";
  public nameOfTheApp = "My First Application";
  public fruits = ['Apple', 'Banana', 'Orange'];
  constructor() { }

  ngOnInit(): void {
  }

  getValue() {
    return 23;
  }
}
